import { A, e } from "./mermaid-parser.core.XPEzvJ1U.js";
export {
  A as ArchitectureModule,
  e as createArchitectureServices
};
