import { I, c } from "./mermaid-parser.core.XPEzvJ1U.js";
export {
  I as InfoModule,
  c as createInfoServices
};
