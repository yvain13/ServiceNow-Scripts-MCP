import { G, f } from "./mermaid-parser.core.XPEzvJ1U.js";
export {
  G as GitGraphModule,
  f as createGitGraphServices
};
