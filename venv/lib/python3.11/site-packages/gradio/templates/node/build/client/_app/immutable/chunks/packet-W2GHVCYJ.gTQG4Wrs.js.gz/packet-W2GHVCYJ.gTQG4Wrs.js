import { P, a } from "./mermaid-parser.core.XPEzvJ1U.js";
export {
  P as PacketModule,
  a as createPacketServices
};
