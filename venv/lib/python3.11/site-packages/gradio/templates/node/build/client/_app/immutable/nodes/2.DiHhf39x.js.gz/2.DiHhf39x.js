import { W, _ } from "../chunks/2.CVBvvKYD.js";
export {
  W as component,
  _ as universal
};
